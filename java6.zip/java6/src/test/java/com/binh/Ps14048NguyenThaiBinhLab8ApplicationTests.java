package com.binh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ps14048NguyenThaiBinhLab8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
